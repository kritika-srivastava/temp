export class Products {
    name: string = '';
    brand: string = '';
    quantity: number = 0;
    price: number = 0;
    id: number = 0;
}
