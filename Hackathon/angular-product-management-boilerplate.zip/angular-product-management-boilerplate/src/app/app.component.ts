import { Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs';
import { Products } from './products';
import { ProductService } from './services/product.service';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  title = 'productapp';
  constructor(private service: ProductService) { }

  productslist: Products[] = [];
  errormessage = '';


  addProduct(product: Products) {

    this.service.addProduct(product).subscribe();
    
  }

  deleteProduct(id: number) {
    this.service.deleteProduct(id).subscribe();
   
  }
  ngOnInit() {
    this.service.getProducts().subscribe((res) => this.productslist = res);
  }
}
