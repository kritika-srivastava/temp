package com.stackroute.exceptions;

public class CustomerNotExists extends Exception {
	
	public CustomerNotExists(String msg) {
		super(msg);
	}


}
